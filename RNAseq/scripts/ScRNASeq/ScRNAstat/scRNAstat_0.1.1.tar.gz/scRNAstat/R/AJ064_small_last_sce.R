#' Small `AJ064` Seurat Data After Processed
#'
#' An object of class Seurat
"AJ064_small_last_sce"
