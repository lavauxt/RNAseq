#' Small `AJ064` Seurat Data Set
#'
#' An object of class Seurat
"AJ064_small_sce"
