utils::globalVariables(c("percent_mito","percent_ribo","percent_hb","nFeature_RNA",
                         "cluster","avg_log2FC"))
